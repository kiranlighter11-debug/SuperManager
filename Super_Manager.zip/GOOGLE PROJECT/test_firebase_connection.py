"""
Test Firebase Firestore Connection
"""
import asyncio
import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

from dotenv import load_dotenv
load_dotenv()

async def test_firebase():
    """Test Firebase connection"""
    print("=" * 70)
    print("Testing Firebase Firestore Connection")
    print("=" * 70)
    print()
    
    try:
        # Test 1: Initialize database
        print("[TEST 1] Initializing Firestore connection...")
        from backend.database import init_db, get_firestore_client
        
        await init_db()
        print("  [OK] Firestore client initialized")
        print()
        
        # Test 2: Test write operation
        print("[TEST 2] Testing write operation...")
        from backend.database import create_task, Task
        
        test_task = Task(
            user_id="test_user",
            intent="Test Firebase connection",
            status="completed",
            result="Connection successful",
            steps=[],
            task_metadata={"test": True}
        )
        
        task_id = await create_task(test_task)
        print(f"  [OK] Task created with ID: {task_id}")
        print()
        
        # Test 3: Test read operation
        print("[TEST 3] Testing read operation...")
        from backend.database import get_task
        
        retrieved_task = await get_task(task_id)
        if retrieved_task:
            print(f"  [OK] Task retrieved: {retrieved_task.intent}")
            print(f"  [OK] Status: {retrieved_task.status}")
        else:
            print("  [FAIL] Task not found")
            return False
        print()
        
        # Test 4: Test memory operations
        print("[TEST 4] Testing memory operations...")
        from backend.database import create_memory, get_memory_by_key, Memory
        
        test_memory = Memory(
            user_id="test_user",
            key="test_key",
            value="test_value",
            context={"test": True}
        )
        
        memory_id = await create_memory(test_memory)
        print(f"  [OK] Memory created with ID: {memory_id}")
        
        retrieved_memory = await get_memory_by_key("test_user", "test_key")
        if retrieved_memory:
            print(f"  [OK] Memory retrieved: {retrieved_memory.key} = {retrieved_memory.value}")
        else:
            print("  [FAIL] Memory not found")
            return False
        print()
        
        # Test 5: Test query operations
        print("[TEST 5] Testing query operations...")
        from backend.database import get_tasks_by_user
        
        tasks = await get_tasks_by_user("test_user", limit=5)
        print(f"  [OK] Found {len(tasks)} tasks for test_user")
        print()
        
        print("=" * 70)
        print("[SUCCESS] All Firebase tests passed!")
        print("=" * 70)
        print()
        print("Firebase Firestore is working correctly!")
        print("Your credentials are configured properly.")
        print()
        
        return True
        
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        print()
        print("Troubleshooting:")
        print("1. Check that firebase-credentials.json exists")
        print("2. Verify FIREBASE_CREDENTIALS_PATH in .env points to the file")
        print("3. Ensure Firestore is enabled in Firebase Console")
        print("4. Check that the service account has proper permissions")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(test_firebase())
    sys.exit(0 if success else 1)

