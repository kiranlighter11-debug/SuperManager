"""
Test Browser-Based Meeting Creation
Opens Google Meet/Zoom in browser - NO API NEEDED
"""
import asyncio
import sys
from pathlib import Path

project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

async def test_browser_meeting():
    print("="*70)
    print("BROWSER-BASED MEETING TEST")
    print("="*70)
    print()
    
    from backend.core.browser_meeting_plugin import BrowserMeetingPlugin
    
    plugin = BrowserMeetingPlugin()
    
    print("Testing Google Meet (Instant Meeting)...")
    print()
    
    # Test Google Meet
    result = await plugin.execute({
        "action": "schedule meeting",
        "parameters": {
            "topic": "Test Meeting",
            "platform": "google_meet"
        }
    }, {})
    
    print("="*70)
    print("RESULT")
    print("="*70)
    print(f"Status: {result.get('status')}")
    print(f"Message: {result.get('result')}")
    print()
    
    if 'meeting' in result:
        meeting = result['meeting']
        print("Meeting Details:")
        print(f"  Platform: {meeting.get('platform')}")
        print(f"  Status: {meeting.get('status')}")
        print()
        print("Instructions:")
        print(meeting.get('instructions', 'No instructions'))
    
    print()
    print("="*70)
    print("WHAT HAPPENED:")
    print("="*70)
    print("✅ Google Meet opened in your browser")
    print("✅ Instant meeting created (no sign-in required)")
    print("✅ Meeting link is in the browser URL bar")
    print("✅ Copy the link from browser and share it!")
    print()
    print("Example link format: https://meet.google.com/abc-defg-hij")
    print()

if __name__ == "__main__":
    asyncio.run(test_browser_meeting())
