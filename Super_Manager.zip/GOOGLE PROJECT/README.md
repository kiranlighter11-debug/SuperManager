# Super Manager - AI Agent System

A next-generation AI agent system that bridges the intent-to-action gap, replacing traditional search-based models with direct task execution.

## 🎯 Core Features

- **Natural-language task execution** - Process user intent and execute tasks
- **Multi-step autonomous workflows** - Plan and execute complex tasks
- **Memory and personalization** - Remember user preferences and context
- **API integrations** - Calendar, Email, Search, and more
- **Reasoning loop** - Iterative refinement and planning
- **Plugin architecture** - Extensible capability system

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- Node.js 18+
- OpenAI API key

### Backend Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up environment variables:
```bash
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

3. Run the backend:
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

### Frontend Setup

1. Install dependencies:
```bash
cd frontend
npm install
```

2. Run the frontend:
```bash
npm run dev
```

3. Open http://localhost:3000 in your browser

## 📁 Project Structure

```
.
├── backend/
│   ├── main.py              # FastAPI application
│   ├── database.py          # Database models and setup
│   ├── core/
│   │   ├── agent.py         # Core agent with reasoning loop
│   │   ├── intent_parser.py # Intent parsing system
│   │   ├── task_planner.py  # Task planning engine
│   │   ├── memory.py        # Memory management
│   │   └── plugins.py       # Plugin architecture
│   └── routes/
│       ├── agent.py         # Agent API endpoints
│       ├── tasks.py         # Task management endpoints
│       ├── memory.py        # Memory endpoints
│       └── plugins.py       # Plugin endpoints
├── frontend/
│   ├── src/
│   │   ├── App.jsx          # Main React component
│   │   └── main.jsx         # React entry point
│   └── package.json
└── requirements.txt
```

## 🔧 Architecture

### Core Components

1. **Agent Manager** - Main reasoning loop that processes intents
2. **Intent Parser** - Extracts action, entities, and constraints
3. **Task Planner** - Creates multi-step execution plans
4. **Memory Manager** - Stores and retrieves user context
5. **Plugin System** - Extensible capability framework

### API Endpoints

- `POST /api/agent/process` - Process user intent
- `GET /api/tasks/` - Get user tasks
- `GET /api/memory/` - Get user memories
- `GET /api/plugins/` - List available plugins

## 🧪 Usage Examples

### Example 1: Schedule a Meeting
```
User: "Schedule a meeting tomorrow at 2pm"
Agent: Processes intent → Plans steps → Executes calendar plugin → Confirms
```

### Example 2: Send Email
```
User: "Send an email to john@example.com about the project"
Agent: Extracts recipient and topic → Plans email action → Executes email plugin
```

### Example 3: Search and Analyze
```
User: "Find information about AI agents and summarize"
Agent: Plans search → Executes search → Analyzes results → Returns summary
```

## 🔌 Plugins

Built-in plugins:
- **General** - Basic task execution
- **Calendar** - Scheduling and appointments
- **Email** - Email operations
- **Search** - Information retrieval

Add custom plugins by extending `BasePlugin`.

## 🗄️ Database

Uses SQLite by default (configurable via `DATABASE_URL`):
- Tasks table - Stores task execution history
- Memories table - User preferences and context
- Conversations table - Chat history

## 🛠️ Development

### Adding a New Plugin

1. Create a class extending `BasePlugin`:
```python
class MyPlugin(BasePlugin):
    def __init__(self):
        super().__init__("myplugin", "My plugin description")
    
    async def execute(self, step, state):
        # Your implementation
        return {"status": "completed", "result": "..."}
    
    def get_capabilities(self):
        return ["capability1", "capability2"]
```

2. Register in `PluginManager`:
```python
plugin_manager.register(MyPlugin())
```

## 📝 Environment Variables

- `OPENAI_API_KEY` - Your OpenAI API key (required)
- `OPENAI_MODEL` - Model to use (default: gpt-4-turbo-preview)
- `DATABASE_URL` - Database connection string

## 🚧 Roadmap

- [x] Core agent reasoning loop
- [x] Intent parsing
- [x] Task planning
- [x] Memory system
- [x] Plugin architecture
- [x] Basic UI
- [ ] Advanced integrations (Google Calendar, Gmail, etc.)
- [ ] Multi-agent collaboration
- [ ] Deployable SaaS version
- [ ] Authentication and multi-user support

## 📄 License

MIT License

## 🤝 Contributing

Contributions welcome! This is a working implementation with real functionality.

