"""
Test the complete multi-stage birthday party planning flow with execution verification
"""
import requests
import json
import time

API_BASE = "http://localhost:8000/api"

def test_execution_flow():
    print("🎉 Testing Complete Birthday Party Planning Flow with Execution\n")
    
    # Step 1: Initial request
    print("Step 1: Sending initial request...")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "I need to enjoy my birthday this weekend",
        "user_id": "test_exec"
    })
    data = response.json()
    session_id = data['session_id']
    print(f"✓ Session ID: {session_id}")
    
    # Step 2: Select destination (Goa)
    print("Step 2: Selecting Goa...")
    requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "goa"
    })
    
    # Step 3: Select accommodation (Taj Exotica)
    print("Step 3: Selecting Taj Exotica Resort & Spa...")
    requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "taj_exotica"
    })
    
    # Step 4: Select activities
    print("Step 4: Selecting activities...")
    requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["water_sports", "beach_party"]
    })
    
    # Step 5: Select dining (Cake and Restaurant)
    print("Step 5: Selecting dining options (Cake & Restaurant)...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["cake_bakery", "restaurant_booking"]
    })
    data = response.json()
    
    print(f"\n📋 Pending Actions:")
    for action in data.get('pending_actions', []):
        print(f"   • {action['description']} (Plugin: {action['plugin']})")
    
    # Step 6: Confirm and execute
    print("\nStep 6: Confirming and executing...")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    
    print("\n✅ Execution Results:")
    results = data.get('results', [])
    if not results and 'results' in data: # Handle if results key exists but is empty or if it's in a different structure
         # The backend might return results differently, let's check the structure in agent.py
         # It returns a list of dicts with 'action', 'result', 'status'
         pass

    # The backend returns 'results' in the response of confirm endpoint?
    # Let's check agent.py again. Yes:
    # return {
    #     "status": "completed",
    #     "message": "All actions completed successfully.",
    #     "results": results
    # }
    
    for res in data.get("results", []):
        print(f"   • {res['action']}: {res['result']}")
        
    # Verify specific execution results
    execution_log = str(data)
    if "Called Taj Exotica Resort & Spa" in execution_log or "Room reservation confirmed" in execution_log:
        print("\n✅ Verified: Resort reservation call made")
    else:
        print("\n❌ Failed: Resort reservation call NOT found")
        
    if "Birthday cake ordered" in execution_log:
        print("✅ Verified: Cake ordered from bakery")
    else:
        print("❌ Failed: Cake order call NOT found")
        
    if "Table booked" in execution_log:
        print("✅ Verified: Restaurant table booked")
    else:
        print("❌ Failed: Restaurant booking call NOT found")

    return True

if __name__ == "__main__":
    try:
        test_execution_flow()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
