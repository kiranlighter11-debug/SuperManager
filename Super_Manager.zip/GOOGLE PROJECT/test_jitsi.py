import asyncio
from backend.core.browser_meeting_plugin import BrowserMeetingPlugin

async def test_jitsi():
    plugin = BrowserMeetingPlugin()
    
    print("Testing Jitsi Link Generation...")
    result = await plugin.execute({
        "action": "schedule_meeting", 
        "parameters": {"platform": "jitsi", "topic": "Test Meeting"}
    }, {})
    
    print(f"Status: {result['status']}")
    print(f"Result: {result['result']}")
    print(f"Output: {result.get('output')}")
    
    if result.get('output') and result['output'].get('meeting_link'):
        print("✅ SUCCESS: Meeting link generated!")
    else:
        print("❌ FAIL: No meeting link generated")

if __name__ == "__main__":
    asyncio.run(test_jitsi())
