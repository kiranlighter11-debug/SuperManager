# START HERE - Quick Setup Guide

## 🚀 3 Simple Steps to Run

### Step 1: Enable Firebase (2 minutes)
**Click this link and click "ENABLE":**
https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=super-manager-d7ae9

Then create database:
1. Go to https://console.firebase.google.com/
2. Select project: `super-manager-d7ae9`
3. Click "Firestore Database" → "Create Database"
4. Choose "Start in test mode"
5. Select location and click "Enable"

### Step 2: Start Backend
```bash
cd "d:\GOOGLE PROJECT"
python run_backend.py
```
Wait for: "Application startup complete"

### Step 3: Start Frontend (New Terminal)
```bash
cd "d:\GOOGLE PROJECT\frontend"
npm install
npm run dev
```

### Step 4: Open Browser
Go to: **http://localhost:3000**

## ✅ Done!

Now you can use Super Manager!

Try: "Schedule a meeting tomorrow at 2pm"

---

## Need Help?

- **Firebase not working?** Wait 2-3 minutes after enabling API
- **Backend error?** Check port 8000 is free
- **Frontend error?** Run `npm install` first
- **See HOW_TO_RUN.md for detailed steps**

