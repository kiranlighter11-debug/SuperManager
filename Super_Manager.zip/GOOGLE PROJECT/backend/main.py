"""
Super Manager - Main FastAPI Application
A next-generation AI agent system for intent-to-action execution
"""
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import os
import sys
from dotenv import load_dotenv

# Force UTF-8 encoding for stdout/stderr on Windows
if sys.platform.startswith('win'):
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

from .database import init_db
from .routes import agent, tasks, memory, plugins, task_agent
from .core.agent import AgentManager

load_dotenv()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup on startup/shutdown"""
    # Initialize database (non-blocking - won't fail startup if Firebase not ready)
    try:
        await init_db()
    except Exception as e:
        print(f"[WARN] Database initialization warning: {e}")
        print("      Server will start but database features may not work until Firebase is configured.")
    
    app.state.agent_manager = AgentManager()
    yield
    # Cleanup if needed
    pass

app = FastAPI(
    title="Super Manager API",
    description="AI Agent System for Intent-to-Action Execution",
    version="1.0.0",
    lifespan=lifespan
)

# Global exception handler
@app.middleware("http")
async def catch_exceptions_middleware(request: Request, call_next):
    try:
        return await call_next(request)
    except Exception as e:
        import traceback
        from datetime import datetime
        error_msg = f"[CRITICAL] Uncaught exception: {e}\n{traceback.format_exc()}"
        print(error_msg) # Print to stdout (now UTF-8 enabled)
        with open("debug_log.txt", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.utcnow().isoformat()}] {error_msg}\n")
        return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(agent.router, prefix="/api/agent", tags=["agent"])
app.include_router(task_agent.router, prefix="/api/task", tags=["task_agent"])  # NEW
app.include_router(tasks.router, prefix="/api/tasks", tags=["tasks"])
app.include_router(memory.router, prefix="/api/memory", tags=["memory"])
app.include_router(plugins.router, prefix="/api/plugins", tags=["plugins"])

@app.get("/")
async def root():
    return {
        "message": "Super Manager API",
        "status": "operational",
        "version": "1.0.0"
    }

@app.get("/api/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
