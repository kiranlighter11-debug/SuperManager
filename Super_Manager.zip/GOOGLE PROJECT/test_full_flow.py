import asyncio
import json
import requests

BASE_URL = "http://localhost:8000"

async def run_flow():
    # Step 1: Initiate meeting request
    payload = {
        "message": "Schedule a meeting at 2pm tomorrow",
        "user_id": "test_user"
    }
    resp = requests.post(f"{BASE_URL}/api/task/process_v2", json=payload)
    print("--- Process response ---")
    print(resp.json())
    data = resp.json()
    session_id = data.get("session_id")
    if not session_id:
        print("No session created, abort")
        return
    # Step 2: Since we didn't provide missing info, the AI may ask for time etc.
    # For simplicity, provide a follow-up with the needed info (assuming it asks for time)
    # We'll just send the same payload again to simulate user providing info.
    follow_payload = {
        "message": "2pm tomorrow",
        "user_id": "test_user",
        "session_id": session_id
    }
    resp2 = requests.post(f"{BASE_URL}/api/task/process_v2", json=follow_payload)
    print("--- Follow-up response ---")
    print(resp2.json())
    data2 = resp2.json()
    # If confirmation is required, confirm it
    if data2.get("requires_confirmation"):
        confirm_payload = {
            "session_id": session_id,
            "approved": True
        }
        resp_confirm = requests.post(f"{BASE_URL}/api/task/confirm_v2", json=confirm_payload)
        print("--- Confirmation response ---")
        print(resp_confirm.json())

if __name__ == "__main__":
    asyncio.run(run_flow())
