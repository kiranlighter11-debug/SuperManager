try:
    with open("backend.log", "rb") as f:
        f.seek(0, 2)  # Seek to end
        size = f.tell()
        f.seek(max(0, size - 5000))  # Read last 5000 bytes
        content = f.read().decode('utf-8', errors='ignore')
        print(content)
except Exception as e:
    print(f"Error reading log: {e}")
