import requests
import json
import sys

# Redirect stdout to a file and console
class Logger(object):
    def __init__(self):
        self.terminal = sys.stdout
        self.log = open("final_test_output.txt", "w", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

sys.stdout = Logger()

BASE_URL = "http://localhost:8000/api/task"
# ... rest of the script ...

print("=" * 70)
print("TASK-BASED AI SYSTEM DEMO")
print("=" * 70)
print("\nAvailable tasks are defined in task_registry.py")
print("AI intelligently matches user input to tasks\n")

# Test 1: Schedule meeting
print("\n[TEST 1] User: 'I need to set up a video call tomorrow'")
print("-" * 70)
r1 = requests.post(f"{BASE_URL}/process_v2", json={
    "message": "I need to set up a video call tomorrow",
    "user_id": "test"
})
d1 = r1.json()
print(f"AI Response: {d1['response']}")
print(f"Task Matched: {d1.get('task_info', {}).get('task', {}).get('name', 'N/A')}")
print(f"Requires Input: {d1.get('requires_input')}")

# Test 2: Book restaurant
print("\n[TEST 2] User: 'Book a table at Italian restaurant for 4 people'")
print("-" * 70)
r2 = requests.post(f"{BASE_URL}/process_v2", json={
    "message": "Book a table at Italian restaurant for 4 people",
    "user_id": "test"
})
d2 = r2.json()
print(f"AI Response: {d2['response']}")
print(f"Task Matched: {d2.get('task_info', {}).get('task', {}).get('name', 'N/A')}")
print(f"Info Collected: {d2.get('task_info', {}).get('collected', {})}")

# Test 3: General query
print("\n[TEST 3] User: 'Hello, what can you do?'")
print("-" * 70)
r3 = requests.post(f"{BASE_URL}/process_v2", json={
    "message": "Hello, what can you do?",
    "user_id": "test"
})
d3 = r3.json()
print(f"AI Response: {d3['response']}")
if d3.get('task_info', {}).get('available_tasks'):
    print("\nAvailable Tasks:")
    for task in d3['task_info']['available_tasks']:
        print(f"  • {task['name']}: {task['description']}")

print("\n" + "=" * 70)
print("KEY DIFFERENCE FROM OLD SYSTEM:")
print("=" * 70)
print("OLD: Hardcoded regex patterns (r'schedule.*meeting')")
print("NEW: AI reads task descriptions and intelligently matches")
print("\nYou can add new tasks in task_registry.py without changing code!")
print("=" * 70)
