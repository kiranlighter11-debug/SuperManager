import os
from dotenv import load_dotenv

load_dotenv(r"d:\GOOGLE PROJECT\.env")

openai_key = os.getenv("OPENAI_API_KEY")
groq_key = os.getenv("GROQ_API_KEY")

print(f"OpenAI Key present: {bool(openai_key)}")
if openai_key:
    print(f"OpenAI Key length: {len(openai_key)}")
    print(f"OpenAI Key prefix: {openai_key[:3]}...")

print(f"Groq Key present: {bool(groq_key)}")
if groq_key:
    print(f"Groq Key length: {len(groq_key)}")
