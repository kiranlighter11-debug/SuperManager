"""
PROOF: Test with EXACT message from the error
"""
import requests
import json

print("=" * 70)
print("PROOF: Testing EXACT Message That Failed")
print("=" * 70)
print()

# The exact message from the error
message = "i want to enjoy my sister's birthday party this weekend"

print(f"Testing message: '{message}'")
print()

try:
    response = requests.post(
        "http://localhost:8000/api/agent/process",
        json={
            "message": message,
            "user_id": "test_user"
        },
        timeout=10
    )
    
    print(f"Status Code: {response.status_code}")
    print()
    
    if response.status_code == 200:
        data = response.json()
        
        print("[SUCCESS] Request processed successfully!")
        print()
        print("Response:")
        print(f"  {data.get('response', 'N/A')}")
        print()
        print("Intent Parsed:")
        print(f"  Action: {data.get('intent', {}).get('action', 'N/A')}")
        print(f"  Category: {data.get('intent', {}).get('category', 'N/A')}")
        print()
        print("Plan Created:")
        steps = data.get('plan', {}).get('steps', [])
        print(f"  Steps: {len(steps)}")
        for step in steps:
            print(f"    - {step.get('name', 'N/A')} ({step.get('status', 'N/A')})")
        print()
        print("Execution Result:")
        result_status = data.get('result', {}).get('status', 'N/A')
        print(f"  Status: {result_status}")
        print()
        
        if result_status == "completed":
            print("[PROOF] Message processed successfully!")
            print("[PROOF] System is WORKING!")
        else:
            print(f"[INFO] Status: {result_status}")
        
        print()
        print("=" * 70)
        print("PROOF: System works with the exact message that failed!")
        print("=" * 70)
        
    else:
        print(f"[FAIL] Error: {response.status_code}")
        print(f"Response: {response.text}")
        
except requests.exceptions.ConnectionError:
    print("[ERROR] Backend server not running")
    print("Start it with: python run_backend.py")
except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()

