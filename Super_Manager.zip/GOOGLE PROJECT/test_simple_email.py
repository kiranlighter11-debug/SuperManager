"""
Simple direct test of email sending
"""
import requests
import time

API_BASE = "http://localhost:8000/api"

print("Testing meeting flow with real email...")
print("=" * 60)

# Step 1: Create session
print("\n1. Creating session...")
response = requests.post(f"{API_BASE}/agent/process", json={
    "message": "Schedule a meeting",
    "user_id": "test"
})
data = response.json()
session_id = data['session_id']
print(f"   Session: {session_id}")

# Step 2: Select Zoom
print("\n2. Selecting Zoom...")
response = requests.post(f"{API_BASE}/agent/select", json={
    "session_id": session_id,
    "selection": "zoom"
})

# Step 3: Enter email
print("\n3. Entering email: kiranlighter11@gmail.com...")
response = requests.post(f"{API_BASE}/agent/process", json={
    "message": "kiranlighter11@gmail.com",
    "user_id": "test",
    "session_id": session_id
})
data = response.json()

if data.get('requires_confirmation'):
    print("\n4. Confirming and executing...")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    
    print("\n" + "=" * 60)
    print("RESULTS:")
    print("=" * 60)
    
    for result in data.get('results', []):
        status = "✅" if result['status'] == 'completed' else "❌"
        print(f"\n{status} {result['action']}")
        print(f"   {result['result']}")
        
        if result.get('details'):
            details = result['details']
            if 'join_url' in details:
                print(f"   Meeting Link: {details['join_url']}")
            if 'email' in details:
                email_info = details['email']
                print(f"   Email Status: {email_info.get('status', 'unknown')}")
    
    print("\n" + "=" * 60)
    print("✅ TEST COMPLETE - Check kiranlighter11@gmail.com inbox!")
    print("=" * 60)
else:
    print("ERROR: No confirmation received")
    print(data)
