"""
LIVE BACKEND TEST
Sends real HTTP requests to the running backend to prove AI integration
"""
import requests
import json
import time
import sys

def test_live_backend():
    print("="*80)
    print("LIVE BACKEND INTEGRATION PROOF")
    print("="*80)
    print()
    
    url = "http://localhost:8000/api/agent/process"
    
    # Test Case: Birthday in Karnataka
    import uuid
    session_id = str(uuid.uuid4())
    payload = {
        "message": "I want to celebrate my birthday in Karnataka",
        "session_id": session_id
    }
    
    print(f"Sending request to {url}...")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print()
    
    try:
        # Wait for backend to start
        time.sleep(5)
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            print("✅ RESPONSE RECEIVED:")
            print(json.dumps(data, indent=2))
            
            # Verify content
            response_text = data.get("response", "")
            options = data.get("options", [])
            
            print()
            print("="*80)
            print("VERIFICATION")
            print("="*80)
            
            # Check if options are Karnataka-specific (Coorg, Hampi, etc.)
            karnataka_keywords = ['coorg', 'hampi', 'chikmagalur', 'gokarna', 'mysore']
            
            found_karnataka = False
            if options:
                print("Options returned by backend:")
                for opt in options:
                    print(f"- {opt.get('name')} ({opt.get('id')})")
                    if any(k in str(opt).lower() for k in karnataka_keywords):
                        found_karnataka = True
            
            print()
            if found_karnataka:
                print("✅ SUCCESS: Backend returned Karnataka-specific options!")
                print("   This proves the AI logic is active in the live server.")
            else:
                print("⚠️  WARNING: Options do not look like Karnataka specific.")
                print("   (Check if backend is using the fallback or AI)")
                
        else:
            print(f"❌ Error: Status {response.status_code}")
            print(response.text)
            
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        print("Make sure backend is running (python run_backend.py)")

if __name__ == "__main__":
    with open("LIVE_PROOF_LOG.txt", "w", encoding="utf-8") as f:
        sys.stdout = f
        test_live_backend()
        sys.stdout = sys.__stdout__
    
    with open("LIVE_PROOF_LOG.txt", "r", encoding="utf-8") as f:
        print(f.read())
