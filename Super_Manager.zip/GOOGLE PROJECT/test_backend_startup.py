"""
Test Backend Server Startup
Verifies the server can start even if Firebase isn't fully configured
"""
import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

from dotenv import load_dotenv
load_dotenv()

def test_imports():
    """Test all imports work"""
    print("=" * 70)
    print("Testing Backend Server Startup")
    print("=" * 70)
    print()
    
    print("[TEST 1] Testing imports...")
    try:
        from backend.main import app
        print("  [OK] FastAPI app imported")
        
        from backend.core.agent import AgentManager
        print("  [OK] AgentManager imported")
        
        from backend.core.plugins import PluginManager
        print("  [OK] PluginManager imported")
        
        from backend.core.intent_parser import IntentParser
        print("  [OK] IntentParser imported")
        
        from backend.core.task_planner import TaskPlanner
        print("  [OK] TaskPlanner imported")
        
        from backend.routes import agent, tasks, memory, plugins
        print("  [OK] All routes imported")
        
        print()
        return True
    except Exception as e:
        print(f"  [FAIL] Import error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_app_creation():
    """Test FastAPI app can be created"""
    print("[TEST 2] Testing FastAPI app creation...")
    try:
        from backend.main import app
        
        # Check routes are registered
        routes = [route.path for route in app.routes]
        expected_routes = ["/", "/api/health", "/api/agent/process", "/api/tasks/", "/api/plugins/"]
        
        found_routes = [r for r in expected_routes if any(r in route for route in routes)]
        print(f"  [OK] App created with {len(routes)} routes")
        print(f"  [OK] Found {len(found_routes)}/{len(expected_routes)} expected routes")
        
        print()
        return True
    except Exception as e:
        print(f"  [FAIL] App creation error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_agent_manager():
    """Test AgentManager initialization"""
    print("[TEST 3] Testing AgentManager...")
    try:
        from backend.core.agent import AgentManager
        
        agent = AgentManager()
        print("  [OK] AgentManager initialized")
        
        # Test it has required methods
        assert hasattr(agent, 'process_intent')
        assert hasattr(agent, '_parse_intent')
        assert hasattr(agent, '_create_plan')
        print("  [OK] AgentManager has required methods")
        
        print()
        return True
    except Exception as e:
        print(f"  [FAIL] AgentManager error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_plugins():
    """Test plugins"""
    print("[TEST 4] Testing plugins...")
    try:
        from backend.core.plugins import PluginManager
        
        pm = PluginManager()
        plugins = pm.get_all_plugins()
        
        print(f"  [OK] {len(plugins)} plugins registered")
        for name in plugins.keys():
            print(f"      - {name}")
        
        print()
        return True
    except Exception as e:
        print(f"  [FAIL] Plugins error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_database_init():
    """Test database initialization (graceful failure)"""
    print("[TEST 5] Testing database initialization...")
    try:
        import asyncio
        from backend.database import init_db
        
        # This should not fail even if Firebase isn't ready
        asyncio.run(init_db())
        print("  [OK] Database initialization completed (gracefully)")
        
        print()
        return True
    except Exception as e:
        print(f"  [WARN] Database init warning: {e}")
        print("  [NOTE] This is expected if Firebase API isn't enabled yet")
        print()
        return True  # Not a failure - graceful degradation

def main():
    """Run all tests"""
    tests = [
        ("Imports", test_imports),
        ("App Creation", test_app_creation),
        ("Agent Manager", test_agent_manager),
        ("Plugins", test_plugins),
        ("Database Init", test_database_init),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"[FAIL] {name} test crashed: {e}")
            results.append((name, False))
    
    print("=" * 70)
    print("Test Results")
    print("=" * 70)
    
    all_passed = True
    for name, result in results:
        status = "[OK]" if result else "[FAIL]"
        print(f"{status} {name}")
        if not result:
            all_passed = False
    
    print()
    if all_passed:
        print("[SUCCESS] All tests passed! Backend is ready to start.")
        print()
        print("To start the server:")
        print("  python run_backend.py")
        print()
        print("Note: If Firebase isn't enabled yet, database operations")
        print("      will fail but the server will still start.")
    else:
        print("[FAIL] Some tests failed. Check errors above.")
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

