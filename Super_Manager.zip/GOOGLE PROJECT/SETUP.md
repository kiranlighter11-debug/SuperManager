# Super Manager - Setup Guide

## Prerequisites

1. **Python 3.9+** - Install from [python.org](https://www.python.org/downloads/)
2. **Node.js 18+** - Install from [nodejs.org](https://nodejs.org/)
3. **OpenAI API Key** - Get from [platform.openai.com](https://platform.openai.com/api-keys)

## Step-by-Step Setup

### 1. Backend Setup

```bash
# Install Python dependencies
pip install -r requirements.txt

# Create .env file
echo OPENAI_API_KEY=your_key_here > .env
echo OPENAI_MODEL=gpt-4-turbo-preview >> .env
echo DATABASE_URL=sqlite+aiosqlite:///./super_manager.db >> .env

# Run backend (Windows)
start_backend.bat

# Or manually:
cd backend
python -m uvicorn main:app --reload --port 8000
```

Backend will run on: http://localhost:8000

### 2. Frontend Setup

```bash
# Install Node dependencies
cd frontend
npm install

# Run frontend (Windows)
cd ..
start_frontend.bat

# Or manually:
cd frontend
npm run dev
```

Frontend will run on: http://localhost:3000

### 3. Verify Installation

1. Open http://localhost:3000
2. You should see the Super Manager interface
3. Try sending a message like: "Schedule a meeting tomorrow at 2pm"

## Troubleshooting

### Backend Issues

- **Import errors**: Make sure you're in the project root when running
- **Database errors**: Delete `super_manager.db` and restart
- **OpenAI errors**: Check your API key in `.env`

### Frontend Issues

- **Connection errors**: Make sure backend is running on port 8000
- **Build errors**: Run `npm install` again in frontend directory

## Testing the System

### Test Intent Parsing
```bash
curl -X POST http://localhost:8000/api/agent/process \
  -H "Content-Type: application/json" \
  -d '{"message": "Schedule a meeting tomorrow at 2pm", "user_id": "test"}'
```

### Test Plugins
```bash
curl http://localhost:8000/api/plugins/
```

### Test Memory
```bash
curl -X POST "http://localhost:8000/api/memory/?user_id=test" \
  -H "Content-Type: application/json" \
  -d '{"key": "preference", "value": "morning meetings"}'
```

## Production Deployment

For production:
1. Set `OPENAI_MODEL` to a production model
2. Use PostgreSQL instead of SQLite
3. Set up proper authentication
4. Configure CORS for your domain
5. Use environment variables for all secrets

