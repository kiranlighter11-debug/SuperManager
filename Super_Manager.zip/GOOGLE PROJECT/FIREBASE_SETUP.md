# Firebase Firestore Setup Guide

## Overview

Super Manager now uses **Firebase Firestore** instead of SQLite for database storage.

## Setup Steps

### 1. Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select existing one
3. Enable Firestore Database
4. Create a Firestore database (start in test mode for development)

### 2. Get Service Account Credentials

1. Go to Project Settings → Service Accounts
2. Click "Generate New Private Key"
3. Download the JSON file
4. Save it securely (e.g., `firebase-credentials.json`)

### 3. Configure Environment

**Option 1: Use credentials file path**
```bash
# In .env file
FIREBASE_CREDENTIALS_PATH=./firebase-credentials.json
```

**Option 2: Use credentials as JSON string**
```bash
# In .env file
FIREBASE_CREDENTIALS_JSON='{"type":"service_account","project_id":"..."}'
```

**Option 3: Use default credentials (local development)**
```bash
# Install gcloud CLI and authenticate
gcloud auth application-default login
# No env variable needed
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- `google-cloud-firestore`
- `google-auth`

### 5. Test Connection

```bash
python -c "from backend.database import init_db; import asyncio; asyncio.run(init_db())"
```

## Firestore Collections

The system uses these collections:
- `tasks` - User tasks
- `memories` - User memories and preferences
- `conversations` - Chat history

## Security Rules (Production)

For production, set up Firestore security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Tasks: Users can only access their own tasks
    match /tasks/{taskId} {
      allow read, write: if request.auth != null && 
        resource.data.user_id == request.auth.uid;
    }
    
    // Memories: Users can only access their own memories
    match /memories/{memoryId} {
      allow read, write: if request.auth != null && 
        resource.data.user_id == request.auth.uid;
    }
    
    // Conversations: Users can only access their own conversations
    match /conversations/{conversationId} {
      allow read, write: if request.auth != null && 
        resource.data.user_id == request.auth.uid;
    }
  }
}
```

## Migration from SQLite

If you have existing SQLite data:

1. Export data from SQLite
2. Import to Firestore using Firebase Admin SDK
3. Update environment variables

## Troubleshooting

### "Credentials not found"
- Check `FIREBASE_CREDENTIALS_PATH` points to valid file
- Or set `FIREBASE_CREDENTIALS_JSON` with valid JSON
- Or use `gcloud auth application-default login`

### "Permission denied"
- Check service account has Firestore permissions
- Verify Firestore is enabled in Firebase Console
- Check security rules allow access

### "Collection not found"
- Firestore creates collections automatically on first write
- No need to create collections manually

## Benefits of Firestore

✅ **Scalable** - Handles millions of documents
✅ **Real-time** - Can add real-time listeners
✅ **Serverless** - No database server to manage
✅ **Global** - Multi-region support
✅ **Secure** - Built-in security rules
✅ **Fast** - Low latency queries

