"""
Comprehensive verification script for Super Manager
Checks all components, dependencies, and integrations
"""
import sys
import os
import asyncio
from pathlib import Path

def check_python_version():
    """Check Python version"""
    print("[*] Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 9:
        print(f"   [OK] Python {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"   [FAIL] Python 3.9+ required, found {version.major}.{version.minor}")
        return False

def check_dependencies():
    """Check if required packages are installed"""
    print("\n[*] Checking dependencies...")
    required = [
        ("fastapi", "fastapi"),
        ("uvicorn", "uvicorn"),
        ("openai", "openai"),
        ("sqlalchemy", "sqlalchemy"),
        ("pydantic", "pydantic"),
        ("dotenv", "python-dotenv")
    ]
    
    missing = []
    for import_name, package_name in required:
        try:
            __import__(import_name)
            print(f"   [OK] {package_name}")
        except ImportError:
            print(f"   [FAIL] {package_name} - Run: pip install {package_name}")
            missing.append(package_name)
    
    return len(missing) == 0

def check_files():
    """Check if all required files exist"""
    print("\n[*] Checking project structure...")
    required_files = [
        "backend/main.py",
        "backend/database.py",
        "backend/core/agent.py",
        "backend/core/intent_parser.py",
        "backend/core/task_planner.py",
        "backend/core/memory.py",
        "backend/core/plugins.py",
        "backend/routes/agent.py",
        "frontend/package.json",
        "frontend/src/App.jsx",
        "requirements.txt"
    ]
    
    all_exist = True
    for file in required_files:
        if Path(file).exists():
            print(f"   [OK] {file}")
        else:
            print(f"   [FAIL] {file} - Missing!")
            all_exist = False
    
    return all_exist

def check_env():
    """Check environment configuration"""
    print("\n[*] Checking environment...")
    env_file = Path(".env")
    
    if env_file.exists():
        print("   [OK] .env file exists")
        
        # Check for API key
        from dotenv import load_dotenv
        load_dotenv()
        
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key and api_key != "your_openai_api_key_here":
            print("   [OK] OPENAI_API_KEY is set")
            return True
        else:
            print("   [WARN] OPENAI_API_KEY not configured (set in .env)")
            return False
    else:
        print("   [WARN] .env file not found (create from .env.example)")
        return False

async def test_imports():
    """Test if all modules can be imported"""
    print("\n[*] Testing imports...")
    
    # Add project root to path for proper imports
    project_root = Path(__file__).parent.absolute()
    sys.path.insert(0, str(project_root))
    
    modules = [
        ("backend.database", "Database models"),
        ("backend.core.agent", "Agent manager"),
        ("backend.core.intent_parser", "Intent parser"),
        ("backend.core.task_planner", "Task planner"),
        ("backend.core.memory", "Memory manager"),
        ("backend.core.plugins", "Plugin system"),
        ("backend.routes.agent", "Agent routes"),
    ]
    
    all_ok = True
    for module_name, description in modules:
        try:
            __import__(module_name)
            print(f"   [OK] {description}")
        except Exception as e:
            print(f"   [FAIL] {description}: {e}")
            all_ok = False
    
    return all_ok

async def test_plugins():
    """Test plugin system"""
    print("\n[*] Testing plugins...")
    try:
        project_root = Path(__file__).parent.absolute()
        sys.path.insert(0, str(project_root))
        from backend.core.plugins import PluginManager
        
        manager = PluginManager()
        plugins = manager.get_all_plugins()
        
        if len(plugins) >= 4:
            print(f"   [OK] {len(plugins)} plugins registered")
            for name in plugins.keys():
                print(f"      - {name}")
            return True
        else:
            print(f"   [WARN] Only {len(plugins)} plugins found (expected 4+)")
            return False
    except Exception as e:
        print(f"   [FAIL] Plugin test failed: {e}")
        return False

def main():
    """Run all checks"""
    print("=" * 60)
    print("Super Manager - Installation Verification")
    print("=" * 60)
    
    checks = [
        ("Python Version", check_python_version, False),
        ("Dependencies", check_dependencies, False),
        ("Project Files", check_files, False),
        ("Environment", check_env, True),  # Warning only
        ("Imports", lambda: asyncio.run(test_imports()), False),
        ("Plugins", lambda: asyncio.run(test_plugins()), False),
    ]
    
    results = []
    for name, check_func, is_warning in checks:
        try:
            result = check_func()
            results.append((name, result, is_warning))
        except Exception as e:
            print(f"   [FAIL] Error: {e}")
            results.append((name, False, is_warning))
    
    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    
    critical_failed = False
    for name, result, is_warning in results:
        if result:
            print(f"[OK] {name}")
        elif is_warning:
            print(f"[WARN] {name} (warning)")
        else:
            print(f"[FAIL] {name} (critical)")
            critical_failed = True
    
    print("\n" + "=" * 60)
    if critical_failed:
        print("[FAIL] Some critical checks failed. Please fix them before running.")
        print("\nNext steps:")
        print("1. Install missing dependencies: pip install -r requirements.txt")
        print("2. Create .env file with OPENAI_API_KEY")
        print("3. Run this script again to verify")
        return 1
    else:
        print("[OK] All critical checks passed!")
        print("\n[READY] You're ready to start Super Manager:")
        print("1. Backend: python -m uvicorn backend.main:app --reload")
        print("2. Frontend: cd frontend && npm run dev")
        print("3. Open: http://localhost:3000")
        return 0

if __name__ == "__main__":
    sys.exit(main())

