import asyncio
import os
from dotenv import load_dotenv
from backend.core.conversation_manager import get_conversation_manager
from backend.core.plugins import PluginManager

# Load env vars
load_dotenv()

async def run_proof():
    with open("PROOF_LOG.txt", "w", encoding="utf-8") as f:
        def log(msg):
            print(msg)
            f.write(msg + "\n")
            
        log("🚀 Starting Meeting & Telegram Proof...")
        
        # 1. Initialize Manager
        cm = get_conversation_manager()
        
        # 2. Create Session (Intent: Schedule Meeting)
        intent = {
            "type": "meeting_scheduling",
            "original_input": "Schedule a Zoom meeting with Alice"
        }
        session = await cm.create_session(intent)
        log(f"✅ Session Created: {session.session_id}")
        
        # 3. Stage 1: Platform Selection -> Select Zoom
        log("\n🔹 Stage 1: Platform Selection")
        current_stage = session.get_current_stage()
        log(f"   Question: {current_stage.data['question']}")
        response = {"selection": "zoom"}
        result = await cm.process_user_response(session.session_id, response)
        log(f"   Selected: Zoom")
        
        # REFRESH SESSION
        session = cm.get_session(session.session_id)
        
        # 4. Stage 2: Participant Details
        log("\n🔹 Stage 2: Participant Details")
        current_stage = session.get_current_stage()
        log(f"   Question: {current_stage.data['question']}")
        response = {"text_input": "Alice (alice@example.com)"}
        result = await cm.process_user_response(session.session_id, response)
        log(f"   Input: Alice (alice@example.com)")
        
        # REFRESH SESSION
        session = cm.get_session(session.session_id)
        
        # 5. Stage 3: Confirmation -> Generate Plan
        log("\n🔹 Stage 3: Confirmation & Plan Generation")
        current_stage = session.get_current_stage()
        # In the real flow, the user confirms here. We'll simulate generating the plan directly.
        plan = cm.generate_execution_plan(session)
        log("   ✅ Plan Generated:")
        for action in plan['actions']:
            log(f"      - {action['type']} (Plugin: {action['plugin']})")
            
        # 6. Execute Actions (Simulate Agent Execution)
        log("\n🔹 Executing Actions...")
        plugin_manager = PluginManager()
        context = {}
        meeting_link = None
        
        for action in plan['actions']:
            plugin_name = action['plugin']
            plugin = plugin_manager.get_plugin(plugin_name)
            
            step = {
                "action": action['type'],
                "parameters": action['parameters']
            }
            
            # Inject meeting link if available (for Telegram)
            if plugin_name == 'telegram' and meeting_link:
                # The plugin handles the placeholder replacement, but we need to pass it in state/context
                context['meeting_link'] = meeting_link
                
            log(f"   ▶️ Executing {plugin_name}...")
            result = await plugin.execute(step, context)
            
            if result['status'] == 'completed':
                log(f"      ✅ Success: {result['result']}")
                if plugin_name == 'zoom':
                    meeting_link = result['output']['join_url']
                    log(f"      🔗 Zoom Link Generated: {meeting_link}")
            else:
                log(f"      ❌ Failed: {result.get('error')}")

        log("\n✨ Proof Complete!")

if __name__ == "__main__":
    asyncio.run(run_proof())
