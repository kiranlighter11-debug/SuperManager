import re

text = "create a meeting for now"

patterns = [
    r"schedule.*meeting",
    r"book.*meeting",
    r"arrange.*call",
    r"set.*up.*meeting",
    r"zoom.*meeting",
    r"create.*meeting",
    r"meeting.*now",
    r"meeting.*right now",
    r"start.*meeting",
    r"instant.*meeting"
]

print(f"Testing text: '{text}'")
print("-" * 50)

for pattern in patterns:
    match = re.search(pattern, text)
    if match:
        print(f"✓ MATCH: {pattern}")
    else:
        print(f"✗ NO MATCH: {pattern}")
