# How to Run Super Manager - Step by Step

## Step 1: Enable Firebase API (5 minutes)

### Option A: Direct Link (Easiest)
1. **Click this link:**
   https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=super-manager-d7ae9

2. **Click the "ENABLE" button**

3. **Wait 2-3 minutes** for the API to activate

### Option B: Manual Steps
1. Go to https://console.cloud.google.com/
2. Select project: `super-manager-d7ae9`
3. Go to "APIs & Services" → "Library"
4. Search for "Cloud Firestore API"
5. Click "Enable"

## Step 2: Create Firestore Database

1. Go to https://console.firebase.google.com/
2. Select project: `super-manager-d7ae9`
3. Click "Firestore Database" in left menu
4. Click "Create Database"
5. Choose "Start in test mode" (for development)
6. Select location: `us-central` (or your preference)
7. Click "Enable"

## Step 3: Verify Firebase Setup

Run this command to test:
```bash
python test_firebase_connection.py
```

You should see:
```
[OK] Firestore connection successful
[OK] Task created with ID: ...
[OK] Memory created with ID: ...
```

## Step 4: Start the Backend Server

**Open Terminal/Command Prompt:**

```bash
cd "d:\GOOGLE PROJECT"
python run_backend.py
```

You should see:
```
[OK] Firestore connection successful
🚀 Starting Super Manager Backend...
   API will be available at: http://localhost:8000
   API docs at: http://localhost:8000/docs
```

**Keep this terminal open!**

## Step 5: Start the Frontend

**Open a NEW Terminal/Command Prompt:**

```bash
cd "d:\GOOGLE PROJECT\frontend"
npm install
npm run dev
```

You should see:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

**Keep this terminal open too!**

## Step 6: Use the System

1. **Open your browser**
2. **Go to:** http://localhost:3000
3. **You'll see the Super Manager interface**

### Try These Examples:

**Example 1: Schedule a Meeting**
```
Schedule a meeting tomorrow at 2pm
```

**Example 2: Send Email**
```
Send an email to john@example.com about the project
```

**Example 3: Search**
```
Find information about AI agents
```

## Quick Commands Reference

### Start Backend
```bash
cd "d:\GOOGLE PROJECT"
python run_backend.py
```

### Start Frontend
```bash
cd "d:\GOOGLE PROJECT\frontend"
npm run dev
```

### Test Firebase
```bash
python test_firebase_connection.py
```

### Test System
```bash
python test_real_proof.py
```

### Check API Health
Open browser: http://localhost:8000/api/health

### View API Docs
Open browser: http://localhost:8000/docs

## Troubleshooting

### Backend Won't Start
- Check if port 8000 is already in use
- Make sure you're in the project directory
- Run: `pip install -r requirements.txt`

### Frontend Won't Start
- Make sure you're in `frontend` directory
- Run: `npm install` first
- Check if port 3000 is already in use

### Firebase Errors
- Wait 2-3 minutes after enabling API
- Verify credentials file exists: `firebase-credentials.json`
- Check `.env` file has: `FIREBASE_CREDENTIALS_PATH=firebase-credentials.json`

### "Module not found" Errors
- Run: `pip install -r requirements.txt`
- Make sure you're in the project root directory

## What You'll See

### Backend Running:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
INFO:     Application startup complete.
```

### Frontend Running:
```
  ➜  Local:   http://localhost:3000/
```

### In Browser:
- Beautiful Super Manager interface
- Chat input at bottom
- Task list on right
- Plugin list on right

## That's It!

Once both servers are running:
1. Backend on http://localhost:8000
2. Frontend on http://localhost:3000

Just open the browser and start using it!

