"""
Test the meeting scheduling flow with specific email verification
"""
import requests
import json
import time

API_BASE = "http://localhost:8000/api"
TARGET_EMAIL = "kiranlighter11@gmail.com"

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def test_meeting_email_flow():
    print_section("📅 TESTING MEETING FLOW WITH EMAIL VERIFICATION")
    
    # Step 1: Initial request
    print_section("STEP 1: Initial Request")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "Schedule a meeting for tomorrow",
        "user_id": "test_user_email"
    })
    data = response.json()
    session_id = data.get('session_id')
    
    print(f"✓ Session ID: {session_id}")
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    
    if data.get('stage_type') != 'platform_selection':
        print(f"❌ Expected platform_selection, got {data.get('stage_type')}")
        return False
        
    # Step 2: Select Platform (Zoom)
    print_section("STEP 2: Selecting Zoom")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "zoom"
    })
    data = response.json()
    
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    
    if data.get('stage_type') != 'participant_details':
        print(f"❌ Expected participant_details, got {data.get('stage_type')}")
        return False

    # Step 3: Provide Participant Details (Target Email)
    print_section(f"STEP 3: Providing Email - {TARGET_EMAIL}")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": TARGET_EMAIL,
        "user_id": "test_user_email",
        "session_id": session_id
    })
    data = response.json()
    
    print(f"✓ Requires Confirmation: {data.get('requires_confirmation')}")
    
    if not data.get('requires_confirmation'):
        print(f"❌ Expected confirmation, got {data}")
        return False
        
    print(f"\n📋 Pending Actions:")
    pending_actions = data.get('pending_actions', [])
    for action in pending_actions:
        print(f"   • {action['description']} (Plugin: {action['plugin']})")
    
    # Verify email action is present with correct recipient
    email_action = next((a for a in pending_actions if a['plugin'] == 'email'), None)
    if not email_action:
        print("❌ No email action found!")
        return False
    
    # Check parameters safely
    params = email_action.get('parameters', {})
    recipient = params.get('to')
    
    if recipient != TARGET_EMAIL:
        print(f"❌ Expected recipient {TARGET_EMAIL}, got {recipient}")
        return False
    else:
        print(f"✓ Verified recipient: {recipient}")
    
    # Step 4: Confirm and execute
    print_section("STEP 4: Confirming and Executing")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    
    print(f"\n✅ EXECUTION RESULTS:")
    results = data.get("results", [])
    email_sent = False
    
    for res in results:
        status_icon = "✅" if res['status'] == 'completed' else "❌"
        print(f"   {status_icon} {res['action']}")
        print(f"      → {res['result']}")
        
        if res['action'] == 'send_invites' and res['status'] == 'completed':
            email_sent = True
            
    if email_sent:
        print(f"\n🎉 SUCCESS: Meeting scheduled and email sent to {TARGET_EMAIL}")
        return True
    else:
        print("\n❌ FAILURE: Email was not sent successfully")
        return False

if __name__ == "__main__":
    try:
        # Wait a bit for backend to start
        time.sleep(2)
        success = test_meeting_email_flow()
        exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        exit(1)
