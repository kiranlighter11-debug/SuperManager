# ZOOM API SETUP GUIDE - CREATE REAL MEETINGS

## Problem
The current system generates fake Google Meet links that don't work because they're not created through the actual Google Calendar API.

## Solution
Use Zoom API to create **REAL, WORKING** meeting links.

---

## Step 1: Create Zoom App

1. Go to https://marketplace.zoom.us/
2. Click "Develop" → "Build App"
3. Choose "Server-to-Server OAuth"
4. Fill in app details:
   - App Name: "Super Manager Meeting Bot"
   - Company Name: Your company
   - Developer Contact: Your email

5. Click "Create"

---

## Step 2: Get API Credentials

After creating the app, you'll see:
- **Account ID**
- **Client ID**
- **Client Secret**

Copy these values.

---

## Step 3: Add Scopes

In the app settings, go to "Scopes" and add:
- `meeting:write:admin` - Create meetings
- `meeting:read:admin` - Read meeting details
- `user:read:admin` - Read user info

Click "Done" and "Continue"

---

## Step 4: Activate App

Click "Activate your app" button

---

## Step 5: Configure Environment

Add to your `.env` file:
```
ZOOM_ACCOUNT_ID=your_account_id_here
ZOOM_CLIENT_ID=your_client_id_here
ZOOM_CLIENT_SECRET=your_client_secret_here
```

---

## Step 6: Install Required Package

```bash
pip install requests
```

---

## Step 7: Test Real Meeting Creation

Run the test script:
```bash
python test_zoom_real.py
```

This will create a REAL Zoom meeting and give you a working link!

---

## Alternative: Use Current Simulation

If you don't want to set up Zoom API right now, the system will:
1. Clearly mark links as "SIMULATION"
2. Provide instructions on how to enable real meetings
3. Still demonstrate the workflow

---

## Verification

After setup, when you schedule a meeting, you'll get:
- ✅ Real Zoom meeting link (e.g., `https://zoom.us/j/123456789`)
- ✅ Meeting password
- ✅ Meeting ID
- ✅ Link works immediately - anyone can join

---

## Cost

Zoom API is **FREE** for:
- Up to 100 participants per meeting
- 40-minute limit on group meetings
- Unlimited 1-on-1 meetings

Perfect for testing and small teams!
