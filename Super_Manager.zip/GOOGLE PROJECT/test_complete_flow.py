"""
Test the complete multi-stage birthday party planning flow
"""
import requests
import json

API_BASE = "http://localhost:8000/api"

def test_complete_flow():
    print("🎉 Testing Complete Birthday Party Planning Flow\n")
    
    # Step 1: Initial request
    print("Step 1: Sending initial request...")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "I need to enjoy my birthday this weekend",
        "user_id": "test"
    })
    data = response.json()
    print(f"✓ Response: {data['response']}")
    print(f"✓ Options: {[opt['name'] for opt in data.get('options', [])]}")
    print(f"✓ Session ID: {data.get('session_id')}")
    print(f"✓ Stage Type: {data.get('stage_type')}\n")
    
    session_id = data['session_id']
    
    # Step 2: Select destination (Goa)
    print("Step 2: Selecting Goa...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "goa"
    })
    data = response.json()
    print(f"✓ Response: {data.get('response')}")
    print(f"✓ Options: {[opt['name'] for opt in data.get('options', [])]}")
    print(f"✓ Stage Type: {data.get('stage_type')}\n")
    
    # Step 3: Select accommodation (Taj Exotica)
    print("Step 3: Selecting Taj Exotica Resort & Spa...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "taj_exotica"
    })
    data = response.json()
    print(f"✓ Response: {data.get('response')}")
    print(f"✓ Options: {[opt['name'] for opt in data.get('options', [])]}")
    print(f"✓ Stage Type: {data.get('stage_type')}\n")
    
    # Step 4: Select activities (Water Sports and Beach Party)
    print("Step 4: Selecting activities...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["water_sports", "beach_party"]
    })
    data = response.json()
    print(f"✓ Response: {data.get('response')}")
    print(f"✓ Options: {[opt['name'] for opt in data.get('options', [])]}")
    print(f"✓ Stage Type: {data.get('stage_type')}\n")
    
    # Step 5: Select dining (Cake from bakery)
    print("Step 5: Selecting dining options...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["cake_bakery"]
    })
    data = response.json()
    print(f"✓ Status: {data.get('status')}")
    print(f"✓ Response: {data.get('response')}")
    
    if data.get('pending_actions'):
        print(f"\n📋 Pending Actions:")
        for action in data['pending_actions']:
            print(f"   • {action['description']}")
    
    # Step 6: Confirm and execute
    print("\nStep 6: Confirming and executing...")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    print(f"✓ Status: {data.get('status')}")
    print(f"\n{data.get('message')}")
    
    print("\n✅ COMPLETE FLOW TEST PASSED!")
    return True

if __name__ == "__main__":
    try:
        test_complete_flow()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
