import requests
import json

# Test the improved flow
BASE_URL = "http://localhost:8000/api/agent"

# Step 1: Initial request
print("Step 1: Schedule meeting right now")
r1 = requests.post(f"{BASE_URL}/process", json={
    "message": "Schedule meeting right now",
    "user_id": "test",
    "session_id": None
})
d1 = r1.json()
session_id = d1["session_id"]
print(f"Response: {d1['response']}")
print(f"Stage: {d1.get('stage_type')}")
print()

# Step 2: Provide time
print("Step 2: at 17:00")
r2 = requests.post(f"{BASE_URL}/process", json={
    "message": "at 17:00",
    "user_id": "test",
    "session_id": session_id
})
d2 = r2.json()
print(f"Response: {d2['response']}")
print(f"Requires confirmation: {d2.get('requires_confirmation')}")
print(f"Actions: {d2.get('pending_actions')}")
print()

# Save full results
with open("test_results.json", "w") as f:
    json.dump({"step1": d1, "step2": d2}, f, indent=2)

print("Results saved to test_results.json")
