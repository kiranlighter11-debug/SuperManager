"""
Simple debug test to see what's happening with clarification
"""
import requests
import json

API_BASE = "http://localhost:8000/api"

print("Step 1: Create session with clarification")
response = requests.post(f"{API_BASE}/agent/process", json={
    "message": "I need to enjoy my birthday this weekend",
    "user_id": "test_user"
})
data = response.json()
session_id = data.get('session_id')

print(f"Session ID: {session_id}")
print(f"Stage: {data.get('stage_type')}")
print(f"Response: {data.get('response')}")
print()

print("Step 2: Select from clarification")
response = requests.post(f"{API_BASE}/agent/select", json={
    "session_id": session_id,
    "selection": "goa"
})

print(f"Status Code: {response.status_code}")
print(f"Response Text: {response.text}")
print()

try:
    data = response.json()
    print(f"JSON Data: {json.dumps(data, indent=2)}")
except:
    print("Failed to parse JSON")
