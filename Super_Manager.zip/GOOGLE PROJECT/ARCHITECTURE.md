# Super Manager - Architecture Documentation

## System Overview

Super Manager is a complete AI agent system that processes user intent and executes tasks autonomously. It consists of:

1. **Backend API** (FastAPI) - Core agent logic and API endpoints
2. **Frontend UI** (React) - User interface for interaction
3. **Database** (SQLite/PostgreSQL) - Persistent storage
4. **Plugin System** - Extensible capability framework

## Core Components

### 1. Agent Manager (`backend/core/agent.py`)

The heart of the system. Implements the reasoning loop:

```
User Input → Intent Parsing → Task Planning → Execution Loop → Result
```

**Key Methods:**
- `process_intent()` - Main entry point
- `_parse_intent()` - Extract intent using LLM
- `_create_plan()` - Generate execution plan
- `_reasoning_loop()` - Iterative execution with refinement
- `_execute_step()` - Execute individual plan steps

**Reasoning Loop:**
1. Parse user intent
2. Create execution plan
3. Execute steps iteratively
4. Check progress and replan if needed
5. Return final result

### 2. Intent Parser (`backend/core/intent_parser.py`)

Extracts structured information from natural language:

**Output Structure:**
```json
{
  "action": "schedule",
  "category": "calendar",
  "entities": {
    "date": "tomorrow",
    "time": "2pm"
  },
  "constraints": [],
  "priority": "medium",
  "capabilities": ["calendar"]
}
```

**Features:**
- Quick pattern matching for common intents
- Deep LLM-based parsing for complex queries
- Entity extraction (dates, times, locations, amounts)
- Confidence scoring

### 3. Task Planner (`backend/core/task_planner.py`)

Creates multi-step execution plans:

**Plan Structure:**
```json
{
  "steps": [
    {
      "id": 1,
      "name": "Validate input",
      "action": "validate",
      "plugin": "general",
      "parameters": {},
      "dependencies": [],
      "error_handling": "retry"
    }
  ],
  "estimated_duration": "5 minutes",
  "required_plugins": ["calendar"],
  "parallelizable": false
}
```

**Features:**
- Step-by-step planning
- Dependency management
- Error handling strategies
- Plan optimization (topological sorting)

### 4. Memory Manager (`backend/core/memory.py`)

Stores and retrieves user context:

**Memory Types:**
- User preferences
- Conversation history
- Task context
- Personalization data

**Features:**
- Key-value storage
- Context-aware retrieval
- Search functionality
- Automatic caching

### 5. Plugin System (`backend/core/plugins.py`)

Extensible architecture for capabilities:

**Base Plugin Interface:**
```python
class BasePlugin(ABC):
    async def execute(step, state) -> Dict
    def get_capabilities() -> List[str]
    def validate_parameters(parameters) -> bool
```

**Built-in Plugins:**
- **GeneralPlugin** - Basic task execution
- **CalendarPlugin** - Scheduling operations
- **EmailPlugin** - Email operations
- **SearchPlugin** - Information retrieval

**Adding Custom Plugins:**
1. Extend `BasePlugin`
2. Implement `execute()` and `get_capabilities()`
3. Register with `PluginManager`

## Data Flow

### Request Processing Flow

```
1. User sends message via UI
   ↓
2. Frontend → POST /api/agent/process
   ↓
3. Agent Manager processes intent
   ├─→ Intent Parser extracts intent
   ├─→ Task Planner creates plan
   ├─→ Memory Manager retrieves context
   └─→ Plugin Manager executes steps
   ↓
4. Results stored in database
   ↓
5. Response sent to frontend
   ↓
6. UI displays result
```

### Database Schema

**Tasks Table:**
- `id` - Primary key
- `user_id` - User identifier
- `intent` - Original user input
- `status` - pending/in_progress/completed/failed
- `result` - Execution result
- `steps` - Plan steps (JSON)
- `metadata` - Additional data (JSON)

**Memories Table:**
- `id` - Primary key
- `user_id` - User identifier
- `key` - Memory key
- `value` - Memory value
- `context` - Additional context (JSON)

**Conversations Table:**
- `id` - Primary key
- `user_id` - User identifier
- `message` - User message
- `response` - Agent response
- `intent` - Parsed intent (JSON)

## API Endpoints

### Agent Endpoints
- `POST /api/agent/process` - Process user intent
- `GET /api/agent/status` - Get agent status

### Task Endpoints
- `GET /api/tasks/` - List user tasks
- `GET /api/tasks/{id}` - Get specific task

### Memory Endpoints
- `POST /api/memory/` - Store memory
- `GET /api/memory/{key}` - Get memory
- `GET /api/memory/` - Get all memories
- `GET /api/memory/search/{query}` - Search memories

### Plugin Endpoints
- `GET /api/plugins/` - List all plugins
- `GET /api/plugins/capabilities` - Get all capabilities

## Frontend Architecture

### Components

**App.jsx** - Main application component
- Manages conversation state
- Handles user input
- Displays messages and tasks
- Shows available plugins

### State Management

- `conversation` - Chat history
- `tasks` - User tasks
- `plugins` - Available plugins
- `loading` - Loading state

### API Integration

Uses Axios for HTTP requests:
- Base URL: `http://localhost:8000/api`
- Automatic error handling
- Loading states

## Extension Points

### Adding New Plugins

1. Create plugin class:
```python
class MyPlugin(BasePlugin):
    def __init__(self):
        super().__init__("myplugin", "Description")
    
    async def execute(self, step, state):
        # Your logic here
        return {"status": "completed", "result": "..."}
    
    def get_capabilities(self):
        return ["capability1", "capability2"]
```

2. Register in `PluginManager._register_default_plugins()`

### Customizing Intent Parsing

Modify `IntentParser._deep_parse()` to:
- Add custom entity extractors
- Enhance pattern matching
- Improve confidence scoring

### Extending Memory

Add new memory types by:
- Extending `MemoryManager` methods
- Adding new database fields
- Implementing custom retrieval logic

## Performance Considerations

1. **Caching**: Memory manager uses in-memory cache
2. **Async Operations**: All I/O is async
3. **Database**: SQLite for development, PostgreSQL for production
4. **LLM Calls**: Batched where possible, cached when appropriate

## Security Considerations

1. **API Keys**: Stored in `.env`, never committed
2. **Input Validation**: Pydantic models validate all inputs
3. **SQL Injection**: SQLAlchemy ORM prevents injection
4. **CORS**: Configured for specific origins
5. **Authentication**: Ready for JWT implementation

## Deployment

### Development
- SQLite database
- Local file storage
- Development server

### Production
- PostgreSQL database
- Environment variables for secrets
- Proper CORS configuration
- Authentication middleware
- Rate limiting
- Logging and monitoring

## Future Enhancements

1. **Multi-agent Collaboration** - Multiple agents working together
2. **Advanced Reasoning** - Chain-of-thought, tool use
3. **Real Integrations** - Google Calendar, Gmail, etc.
4. **Streaming Responses** - Real-time updates
5. **Voice Interface** - Speech input/output
6. **Mobile App** - Native mobile experience

