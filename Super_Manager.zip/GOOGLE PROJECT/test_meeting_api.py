"""
Test the meeting scheduling through the actual backend API
Shows exactly what the frontend will receive
"""
import asyncio
import sys
from pathlib import Path

project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

async def test_meeting_via_agent():
    print("="*70)
    print("TESTING MEETING SCHEDULING VIA AGENT (What Frontend Sees)")
    print("="*70)
    print()
    
    from backend.core.agent import AgentManager
    
    agent = AgentManager()
    
    # Test scheduling a meeting
    user_input = "Schedule a meeting with team@example.com for Project Kickoff tomorrow at 2pm"
    
    print(f"User Input: \"{user_input}\"")
    print()
    print("Processing...")
    print()
    
    result = await agent.process_intent(user_input, "test_user")
    
    print("="*70)
    print("AGENT RESPONSE")
    print("="*70)
    print()
    
    # Show what was executed
    if 'result' in result and 'steps' in result['result']:
        steps = result['result']['steps']
        print(f"Executed {len(steps)} steps:")
        print()
        
        for i, step in enumerate(steps, 1):
            print(f"Step {i}: {step.get('plugin', 'unknown')}.{step.get('action', 'unknown')}")
            print(f"  Status: {step.get('status')}")
            print(f"  Result: {step.get('result')}")
            
            # Show meeting details if present
            if 'meeting' in step:
                meeting = step['meeting']
                print(f"  Meeting Details:")
                print(f"    Topic: {meeting.get('topic')}")
                print(f"    Join URL: {meeting.get('join_url')}")
                print(f"    Platform: {meeting.get('platform')}")
                
                if 'note' in meeting:
                    print(f"    ⚠️  {meeting.get('note')}")
                
                if 'instructions' in meeting:
                    print(f"    📝 {meeting.get('instructions')}")
            
            print()
    
    print("="*70)
    print("VERIFICATION")
    print("="*70)
    print()
    
    # Check if simulation warning is present
    result_str = str(result)
    if "SIMULATION" in result_str:
        print("✅ PASS: Simulation warning is present")
    else:
        print("❌ FAIL: No simulation warning found")
    
    if "meet.google.com" in result_str:
        print("❌ FAIL: Still generating fake Google Meet links")
    else:
        print("✅ PASS: No fake Google Meet links")
    
    if "zoom.us" in result_str or "Zoom" in result_str:
        print("✅ PASS: Using Zoom format")
    else:
        print("⚠️  WARNING: No meeting link format detected")
    
    print()

if __name__ == "__main__":
    asyncio.run(test_meeting_via_agent())
