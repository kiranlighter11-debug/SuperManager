"""
Test the multi-stage meeting scheduling flow
"""
import requests
import json
import time

API_BASE = "http://localhost:8000/api"

def test_meeting_flow():
    print("📅 Testing Multi-Stage Meeting Scheduling Flow\n")
    
    # Step 1: Initial request
    print("Step 1: Sending initial request...")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "Schedule a meeting for tomorrow",
        "user_id": "test_meet"
    })
    data = response.json()
    session_id = data.get('session_id')
    print(f"✓ Session ID: {session_id}")
    print(f"✓ Response: {data.get('response')}")
    print(f"✓ Intent: {data.get('intent')}")
    print(f"✓ Stage Type: {data.get('stage_type')}")
    
    if data.get('stage_type') != 'platform_selection':
        print(f"❌ Expected platform_selection, got {data.get('stage_type')}")
        return False
        
    # Step 2: Select Platform (Zoom)
    print("\nStep 2: Selecting Zoom...")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "zoom"
    })
    print(f"Status Code: {response.status_code}", flush=True)
    print(f"Raw Response: {response.text}", flush=True)
    try:
        data = response.json()
    except:
        data = {}
    print(f"Full Data: {data}", flush=True)
    print(f"✓ Response: {data.get('response')}", flush=True)
    
    if data.get('stage_type') != 'participant_details':
        print(f"❌ Expected participant_details, got {data.get('stage_type')}")
        return False

    # Step 3: Provide Participant Details (Text Input)
    # Note: This uses /agent/process with session_id, simulating text input
    print("\nStep 3: Providing participant details...")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "john@example.com, jane@example.com",
        "user_id": "test_meet",
        "session_id": session_id
    })
    data = response.json()
    
    if not data.get('requires_confirmation'):
        print(f"❌ Expected confirmation, got {data}")
        return False
        
    print(f"\n📋 Pending Actions:")
    for action in data.get('pending_actions', []):
        print(f"   • {action['description']} (Plugin: {action['plugin']})")
    
    # Step 4: Confirm and execute
    print("\nStep 4: Confirming and executing...")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    
    print("\n✅ Execution Results:")
    for res in data.get("results", []):
        print(f"   • {res['action']}: {res['result']}")
        
    return True

if __name__ == "__main__":
    try:
        test_meeting_flow()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
