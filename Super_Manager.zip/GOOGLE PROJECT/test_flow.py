import requests
import json
import time

# Base URL
BASE_URL = "http://localhost:8000/api/agent"

print("=" * 60)
print("TESTING IMPROVED MEETING SCHEDULING FLOW")
print("=" * 60)

# Step 1: Initial request
print("\n[STEP 1] User: 'Schedule meeting right now'")
response1 = requests.post(
    f"{BASE_URL}/process",
    json={
        "message": "Schedule meeting right now",
        "user_id": "test_user",
        "session_id": None
    }
)
data1 = response1.json()
session_id = data1.get("session_id")
print(f"✓ Session created: {session_id}")
print(f"✓ AI Response: {data1.get('response')}")
print(f"✓ Stage type: {data1.get('stage_type')}")
print(f"✓ Requires selection: {data1.get('requires_selection')}")

time.sleep(1)

# Step 2: Respond with time
print("\n[STEP 2] User: 'at 17:00'")
response2 = requests.post(
    f"{BASE_URL}/process",
    json={
        "message": "at 17:00",
        "user_id": "test_user",
        "session_id": session_id
    }
)
data2 = response2.json()
print(f"✓ AI Response: {data2.get('response')}")
print(f"✓ Requires confirmation: {data2.get('requires_confirmation')}")
pending_actions = data2.get('pending_actions') or []
print(f"✓ Pending actions: {len(pending_actions)}")

if pending_actions:
    print("\n[ACTIONS TO BE EXECUTED]:")
    for action in pending_actions:
        print(f"  - {action['description']}")
        print(f"    Type: {action['action_type']}")
        print(f"    Plugin: {action['plugin']}")

# Step 3: Confirm
if data2.get('requires_confirmation'):
    print("\n[STEP 3] User confirms action")
    response3 = requests.post(
        f"{BASE_URL}/confirm",
        json={
            "session_id": session_id,
            "action": "approve_all"
        }
    )
    data3 = response3.json()
    print(f"✓ Execution status: {data3.get('status')}")
    
    if data3.get('results'):
        print("\n[EXECUTION RESULTS]:")
        for result in data3['results']:
            print(f"  - {result.get('description', 'Action')}: {result.get('status', 'unknown')}")
            if result.get('details'):
                print(f"    Details: {json.dumps(result['details'], indent=6)}")

print("\n" + "=" * 60)
print("TEST COMPLETE")
print("=" * 60)
