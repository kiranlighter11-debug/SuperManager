"""
Test script to verify Zoom API integration
Creates a REAL Zoom meeting if API is configured
"""
import asyncio
import sys
from pathlib import Path
from datetime import datetime, timedelta

# Add project root to path
project_root = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_root))

async def test_zoom_real():
    print("="*70)
    print("ZOOM API INTEGRATION TEST")
    print("="*70)
    print()
    
    try:
        from backend.core.zoom_real_plugin import ZoomMeetingPlugin
        
        plugin = ZoomMeetingPlugin()
        
        # Check if API is configured
        if not all([plugin.account_id, plugin.client_id, plugin.client_secret]):
            print("⚠️  Zoom API NOT configured")
            print()
            print("To create REAL meetings, add to .env:")
            print("  ZOOM_ACCOUNT_ID=your_account_id")
            print("  ZOOM_CLIENT_ID=your_client_id")
            print("  ZOOM_CLIENT_SECRET=your_client_secret")
            print()
            print("See ZOOM_SETUP_GUIDE.md for detailed instructions")
            print()
            print("Running in SIMULATION mode...")
            print()
        else:
            print("✅ Zoom API credentials found!")
            print(f"   Account ID: {plugin.account_id[:10]}...")
            print(f"   Client ID: {plugin.client_id[:10]}...")
            print()
        
        # Test meeting creation
        print("[TEST] Creating meeting...")
        result = await plugin.execute({
            "action": "schedule meeting",
            "parameters": {
                "topic": "Test Meeting - Super Manager",
                "duration": "30 mins",
                "start_time": (datetime.now() + timedelta(hours=1)).isoformat()
            }
        }, {})
        
        print()
        print("="*70)
        print("RESULT")
        print("="*70)
        print(f"Status: {result.get('status')}")
        print(f"Message: {result.get('result')}")
        print()
        
        if 'meeting' in result:
            meeting = result['meeting']
            print("Meeting Details:")
            print(f"  Topic: {meeting.get('topic')}")
            print(f"  Platform: {meeting.get('platform')}")
            print(f"  Join URL: {meeting.get('join_url')}")
            
            if meeting.get('password'):
                print(f"  Password: {meeting.get('password')}")
            
            if meeting.get('note'):
                print(f"  Note: {meeting.get('note')}")
            
            print()
            
            # Verify if it's real or simulated
            if "REAL" in meeting.get('platform', ''):
                print("✅ SUCCESS: REAL Zoom meeting created!")
                print("   You can join this meeting right now!")
                print(f"   Link: {meeting.get('join_url')}")
            else:
                print("ℹ️  SIMULATION: This is a demo link")
                print("   Configure Zoom API for real meetings")
        
        print()
        print("="*70)
        
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        print()
        print("Make sure to install: pip install requests")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_zoom_real())
