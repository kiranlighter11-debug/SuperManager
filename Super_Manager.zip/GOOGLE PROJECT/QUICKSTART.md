# Quick Start Guide

## 🚀 Get Running in 5 Minutes

### Step 1: Install Dependencies

**Backend:**
```bash
pip install -r requirements.txt
```

**Frontend:**
```bash
cd frontend
npm install
cd ..
```

### Step 2: Configure Environment

Create `.env` file in project root:
```
OPENAI_API_KEY=sk-your-key-here
OPENAI_MODEL=gpt-4-turbo-preview
DATABASE_URL=sqlite+aiosqlite:///./super_manager.db
```

**Important:** Get your OpenAI API key from https://platform.openai.com/api-keys

### Step 3: Test the System

```bash
python test_system.py
```

This verifies all components are working.

### Step 4: Start the Backend

**Windows:**
```bash
start_backend.bat
```

**Linux/Mac:**
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

Backend runs on: http://localhost:8000

### Step 5: Start the Frontend

**Windows:**
```bash
start_frontend.bat
```

**Linux/Mac:**
```bash
cd frontend
npm run dev
```

Frontend runs on: http://localhost:3000

### Step 6: Use Super Manager

1. Open http://localhost:3000
2. Try these examples:
   - "Schedule a meeting tomorrow at 2pm"
   - "Send an email to john@example.com about the project"
   - "Search for information about AI agents"
   - "Plan my week"

## 🧪 Verify It's Working

### Check Backend Health
```bash
curl http://localhost:8000/api/health
```

### Check Available Plugins
```bash
curl http://localhost:8000/api/plugins/
```

### Test Agent Processing
```bash
curl -X POST http://localhost:8000/api/agent/process \
  -H "Content-Type: application/json" \
  -d "{\"message\": \"Hello, can you help me?\", \"user_id\": \"test\"}"
```

## 🐛 Troubleshooting

### "Module not found" errors
- Make sure you're in the project root directory
- Run `pip install -r requirements.txt` again

### "OPENAI_API_KEY not found"
- Create `.env` file with your API key
- Restart the backend server

### Frontend can't connect to backend
- Make sure backend is running on port 8000
- Check browser console for CORS errors
- Verify proxy settings in `frontend/vite.config.js`

### Database errors
- Delete `super_manager.db` file
- Restart backend (it will recreate the database)

## 📚 Next Steps

- Read `README.md` for full documentation
- Check `SETUP.md` for detailed setup instructions
- Explore the code in `backend/core/` to understand the architecture
- Add custom plugins in `backend/core/plugins.py`

## ✅ What You Have

A fully functional AI agent system with:
- ✅ Intent parsing and understanding
- ✅ Task planning and execution
- ✅ Memory and personalization
- ✅ Plugin architecture (Calendar, Email, Search)
- ✅ Beautiful web interface
- ✅ RESTful API
- ✅ Database persistence

**This is a real, working implementation - not a prototype!**

