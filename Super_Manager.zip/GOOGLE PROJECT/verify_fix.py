import requests
import json
import sys

BASE_URL = "http://localhost:8000/api/agent"

def print_step(step_name):
    print(f"\n{'='*20} {step_name} {'='*20}")

def test_flow():
    session_id = None
    
    # 1. Initial Request
    print_step("1. Initial Request: Plan a birthday party")
    payload = {
        "message": "Plan my son's birthday party",
        "user_id": "test_user"
    }
    try:
        response = requests.post(f"{BASE_URL}/process", json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"Response Status: {response.status_code}")
        print(f"Question: {data.get('response')}")
        session_id = data.get('session_id')
        print(f"Session ID: {session_id}")
    except Exception as e:
        print(f"FAILED: {e}")
        return

    if not session_id:
        print("No session ID returned. Aborting.")
        return

    # 2. Select Destination (Goa)
    print_step("2. Select Destination: Goa")
    payload = {
        "session_id": session_id,
        "selection": "goa"
    }
    try:
        response = requests.post(f"{BASE_URL}/select", json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"Response Status: {response.status_code}")
        print(f"Next Question: {data.get('response')}")
        
        # Check options for Rupee symbol
        options = data.get('options', [])
        print("Options received (checking for encoding issues):")
        for opt in options:
            print(f" - {opt['name']}: {opt.get('price', 'N/A')}")
            
    except Exception as e:
        print(f"FAILED: {e}")
        return

    # 3. Select Accommodation (Taj Exotica)
    print_step("3. Select Accommodation: Taj Exotica")
    payload = {
        "session_id": session_id,
        "selection": "taj_exotica"
    }
    try:
        response = requests.post(f"{BASE_URL}/select", json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"Response Status: {response.status_code}")
        print(f"Next Question: {data.get('response')}")
    except Exception as e:
        print(f"FAILED: {e}")
        return

    # 4. Select Activities
    print_step("4. Select Activities: Water Sports")
    payload = {
        "session_id": session_id,
        "selections": ["water_sports"]
    }
    try:
        response = requests.post(f"{BASE_URL}/select", json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"Response Status: {response.status_code}")
        print(f"Next Question: {data.get('response')}")
    except Exception as e:
        print(f"FAILED: {e}")
        return

    # 5. Select Dining
    print_step("5. Select Dining: Cake")
    payload = {
        "session_id": session_id,
        "selections": ["cake_bakery"]
    }
    try:
        response = requests.post(f"{BASE_URL}/select", json=payload)
        response.raise_for_status()
        data = response.json()
        print(f"Response Status: {response.status_code}")
        print(f"Response: {data.get('response')}")
        print("Status:", data.get('status'))
    except Exception as e:
        print(f"FAILED: {e}")
        return

if __name__ == "__main__":
    test_flow()
