import sys
import os
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path("d:/GOOGLE PROJECT").absolute()))

from backend.core.conversation_manager import get_conversation_manager
from backend.core.session_store import get_session_store

def test_reproduce():
    print("Initializing...")
    cm = get_conversation_manager()
    
    # Create session
    intent = {
        "type": "birthday_party",
        "entities": {}
    }
    session = cm.create_session(intent)
    print(f"Session created: {session.session_id}")
    
    # Process destination selection
    print("Processing destination selection (Goa)...")
    result = cm.process_user_response(
        session.session_id,
        {"selection": "goa"}
    )
    
    print("Result keys:", result.keys())
    if "next_stage" in result:
        print("Next stage options found.")
        options = result["next_stage"].get("options", [])
        for opt in options:
            print(f"Option: {opt.get('name')}")
            # This might crash if console doesn't support it
            try:
                print(f"Price: {opt.get('price')}")
            except UnicodeEncodeError:
                print("Caught UnicodeEncodeError printing price")

if __name__ == "__main__":
    test_reproduce()
