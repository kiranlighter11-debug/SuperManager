"""
Complete end-to-end test for birthday planning flow
This will test the FULL multi-stage flow including action execution
"""
import requests
import json
import time

API_BASE = "http://localhost:8000/api"

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def test_birthday_flow():
    print_section("🎂 COMPLETE BIRTHDAY PLANNING FLOW TEST")
    
    # Step 1: Initial request
    print_section("STEP 1: Initial Request")
    response = requests.post(f"{API_BASE}/agent/process", json={
        "message": "I need to enjoy my birthday this weekend",
        "user_id": "test_user"
    })
    data = response.json()
    session_id = data.get('session_id')
    
    print(f"✓ Session ID: {session_id}")
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    print(f"✓ Options: {len(data.get('options', []))} destinations")
    
    # Handle clarification stage if present
    if data.get('stage_type') == 'clarification':
        print("\n  → Clarification stage detected, selecting destination...")
        response = requests.post(f"{API_BASE}/agent/select", json={
            "session_id": session_id,
            "selection": "goa"
        })
        data = response.json()
        print(f"  → New Stage: {data.get('stage_type')}")
    
    assert data.get('stage_type') == 'destination_selection', f"Expected destination_selection, got {data.get('stage_type')}"
    
    # Step 2: Select Destination (Goa)
    print_section("STEP 2: Selecting Destination - Goa")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "goa"
    })
    data = response.json()
    
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    print(f"✓ Options: {len(data.get('options', []))} accommodations")
    
    assert data.get('stage_type') == 'accommodation_selection', f"Expected accommodation_selection, got {data.get('stage_type')}"
    
    # Step 3: Select Accommodation
    print_section("STEP 3: Selecting Accommodation - Taj Exotica")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selection": "taj_exotica"
    })
    data = response.json()
    
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    print(f"✓ Options: {len(data.get('options', []))} activities")
    
    assert data.get('stage_type') == 'activities_selection', f"Expected activities_selection, got {data.get('stage_type')}"
    
    # Step 4: Select Activities (Multiple)
    print_section("STEP 4: Selecting Activities")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["water_sports", "beach_party", "dolphin_cruise"]
    })
    data = response.json()
    
    print(f"✓ Stage: {data.get('stage_type')}")
    print(f"✓ Question: {data.get('response')}")
    print(f"✓ Options: {len(data.get('options', []))} dining options")
    
    assert data.get('stage_type') == 'dining_selection', f"Expected dining_selection, got {data.get('stage_type')}"
    
    # Step 5: Select Dining Options
    print_section("STEP 5: Selecting Dining Options")
    response = requests.post(f"{API_BASE}/agent/select", json={
        "session_id": session_id,
        "selections": ["cake_bakery", "restaurant_booking"]
    })
    data = response.json()
    
    print(f"✓ Status: {data.get('status')}")
    print(f"✓ Requires Confirmation: {data.get('requires_confirmation')}")
    print(f"✓ Pending Actions: {len(data.get('pending_actions', []))}")
    
    print("\n📋 PENDING ACTIONS:")
    for i, action in enumerate(data.get('pending_actions', []), 1):
        print(f"   {i}. {action['description']} (Plugin: {action['plugin']})")
    
    assert data.get('requires_confirmation'), "Expected confirmation required"
    
    # Step 6: Confirm and Execute
    print_section("STEP 6: Confirming and Executing Actions")
    response = requests.post(f"{API_BASE}/agent/confirm", json={
        "session_id": session_id,
        "action": "approve_all"
    })
    data = response.json()
    
    print(f"✓ Message: {data.get('message')}")
    print(f"\n✅ EXECUTION RESULTS:")
    
    results = data.get('results', [])
    for i, res in enumerate(results, 1):
        status_icon = "✅" if res['status'] == 'completed' else "❌"
        print(f"   {status_icon} {res['action']}")
        print(f"      → {res['result']}")
        if res.get('details'):
            for key, value in res['details'].items():
                print(f"      → {key}: {value}")
    
    # Verify critical actions were executed
    action_types = [r['action'] for r in results]
    
    print_section("VERIFICATION")
    
    checks = [
        ("Resort reservation call", any('resort' in a.lower() or 'taj' in a.lower() for a in action_types)),
        ("Cake order call", any('cake' in a.lower() or 'bakery' in a.lower() for a in action_types)),
        ("Restaurant booking", any('restaurant' in a.lower() or 'dinner' in a.lower() for a in action_types)),
        ("Activity bookings", any('activity' in a.lower() or 'water' in a.lower() or 'beach' in a.lower() for a in action_types)),
        ("Itinerary creation", any('itinerary' in a.lower() for a in action_types))
    ]
    
    all_passed = True
    for check_name, passed in checks:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {check_name}")
        if not passed:
            all_passed = False
    
    print_section("FINAL RESULT")
    if all_passed:
        print("🎉 ALL TESTS PASSED! The complete flow works end-to-end.")
        print(f"✓ Total actions executed: {len(results)}")
        print(f"✓ Session ID: {session_id}")
        return True
    else:
        print("❌ SOME TESTS FAILED!")
        return False

if __name__ == "__main__":
    try:
        success = test_birthday_flow()
        exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ CRITICAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
