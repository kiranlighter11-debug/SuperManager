import requests
import json
import time

BASE_URL = "http://localhost:8000/api/agent"

print("=" * 70)
print("COMPLETE MEETING SCHEDULING FLOW TEST")
print("=" * 70)

# Step 1: User says "Create a meeting for now"
print("\n[STEP 1] User: 'Create a meeting for now'")
print("-" * 70)
r1 = requests.post(f"{BASE_URL}/process", json={
    "message": "Create a meeting for now",
    "user_id": "test_user",
    "session_id": None
})
d1 = r1.json()
session_id = d1["session_id"]

print(f"✓ Session ID: {session_id}")
print(f"✓ AI Response: {d1['response']}")
print(f"✓ Stage: {d1.get('stage_type')}")
print(f"✓ Requires Selection: {d1.get('requires_selection')}")
print(f"✓ Requires Confirmation: {d1.get('requires_confirmation')}")

time.sleep(1)

# Step 2: User types "yes" (confirming the action)
print("\n[STEP 2] User: 'yes'")
print("-" * 70)
r2 = requests.post(f"{BASE_URL}/process", json={
    "message": "yes",
    "user_id": "test_user",
    "session_id": session_id
})
d2 = r2.json()

print(f"✓ Session ID: {d2['session_id']}")
print(f"✓ AI Response: {d2['response']}")
print(f"✓ Stage: {d2.get('stage_type')}")
print(f"✓ Requires Confirmation: {d2.get('requires_confirmation')}")

# Check if actions were executed
if d2.get('result') and d2['result'].get('execution_results'):
    print("\n[EXECUTION RESULTS]")
    print("-" * 70)
    for result in d2['result']['execution_results']:
        print(f"  ✓ {result.get('action', 'Action')}: {result.get('status', 'completed')}")
        if result.get('details'):
            details = result['details']
            if 'join_url' in details:
                print(f"    Meeting URL: {details['join_url']}")
            if 'topic' in details:
                print(f"    Topic: {details['topic']}")

# Check session continuity
print("\n[SESSION CONTINUITY CHECK]")
print("-" * 70)
if d2['session_id'] == session_id:
    print("✓ SUCCESS: Session was preserved across messages!")
else:
    print(f"✗ FAIL: Session changed from {session_id} to {d2['session_id']}")

# Save results
with open("complete_flow_test.json", "w") as f:
    json.dump({"step1": d1, "step2": d2}, f, indent=2)

print("\n" + "=" * 70)
print("TEST COMPLETE - Results saved to complete_flow_test.json")
print("=" * 70)
