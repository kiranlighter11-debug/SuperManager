try:
    with open("test_task_output.txt", "r", encoding="utf-16") as f:
        print(f.read())
except:
    with open("test_task_output.txt", "r", encoding="utf-8") as f:
        print(f.read())
