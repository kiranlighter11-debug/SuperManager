import requests
import json

BASE_URL = "http://localhost:8000/api/agent"

# Step 1
print("=== STEP 1: Schedule meeting right now ===")
r1 = requests.post(f"{BASE_URL}/process", json={
    "message": "Schedule meeting right now",
    "user_id": "test",
    "session_id": None
})
d1 = r1.json()
session_id = d1["session_id"]
print(f"Session ID: {session_id}")
print(f"Response: {d1['response']}")
print(f"Stage type: {d1.get('stage_type')}")
print()

# Step 2 - WITH session_id
print("=== STEP 2: at 17:00 (with session_id) ===")
r2 = requests.post(f"{BASE_URL}/process", json={
    "message": "at 17:00",
    "user_id": "test",
    "session_id": session_id  # IMPORTANT: Using same session
})
d2 = r2.json()
print(f"Session ID: {d2['session_id']}")
print(f"Response: {d2['response']}")
print(f"Stage type: {d2.get('stage_type')}")
print(f"Requires confirmation: {d2.get('requires_confirmation')}")

# Check if session IDs match
if d2['session_id'] == session_id:
    print("\n✓ Session continued correctly!")
else:
    print(f"\n✗ ERROR: New session created! Expected {session_id}, got {d2['session_id']}")

with open("session_test.json", "w") as f:
    json.dump({"step1": d1, "step2": d2}, f, indent=2)
