
with open("debug_log.txt", "r") as f:
    lines = f.readlines()
    for line in lines[-5:]:
        print(line.strip())
